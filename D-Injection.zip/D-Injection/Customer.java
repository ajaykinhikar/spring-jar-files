public class Customer
{
private String custnm;
//Product obj=new Product("Microsoft Surface",123500.00);
Product p;

public Customer(String custnm,Product p)
{
this.custnm=custnm;
this.p=p;
}

public void showCustomerInfo()
{
System.out.println("Customer Name : "+custnm);
p.getProductDetails();
}
}
