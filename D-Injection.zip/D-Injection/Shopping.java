class Shopping
{
public static void main(String p[])
{
Product p1=new Product("Samsung Mobile",16500.00);
Product p2=new Product("Apple Ipad",37900.00);
Product p3=new Product("HP laptop",45000.00);


Customer c1=new Customer("Ethan Hunt",p1);
c1.showCustomerInfo();

Customer c2=new Customer("Praffull",p2);
c2.showCustomerInfo();

Customer c3=new Customer("Sharayu",p3);
c3.showCustomerInfo();


}
}