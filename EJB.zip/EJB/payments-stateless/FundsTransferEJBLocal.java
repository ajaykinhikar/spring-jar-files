package com.payments.businesslogic;

import javax.ejb.Local;

@Local
public interface FundsTransferEJBLocal 
{
	public double findBalance(int accno);
	public String transferAmount(int sourceaccno,int destaccno,double amount);

}
