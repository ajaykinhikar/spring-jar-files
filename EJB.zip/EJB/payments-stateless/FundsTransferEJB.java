package com.payments.businesslogic;

import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import java.sql.*;

/**
 * Session Bean implementation class FundsTransferEJB
 */
@Stateless(mappedName = "trans")
@LocalBean
public class FundsTransferEJB implements FundsTransferEJBLocal {

    /**
     * Default constructor. 
     */
	
	Connection con;
	PreparedStatement pst;
	ResultSet rs;
	
    public FundsTransferEJB() {
        // TODO Auto-generated constructor stub
    	
    }

    public double findBalance(int accno)
    {
    	double balance=0.0;
    	try
    	{
    		Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/transactdb?user=root&password=volkswagen");
			pst=con.prepareStatement("select balance from accounts where accno=?;");
			pst.setInt(1, accno);
			rs=pst.executeQuery();
			if(rs.next())
				balance=rs.getDouble("balance");
			
			con.close();
    	}
    	catch(Exception e)
    	{
    		System.out.println(e);
    		balance=-1;
    	}
    	return(balance);
    }
	public String transferAmount(int sourceaccno,int destaccno,double amount)
	{
		String transferstatus="";
		try
		{
			Class.forName("com.mysql.cj.jdbc.Driver");
			con=DriverManager.getConnection("jdbc:mysql://localhost:3306/transactdb?user=root&password=volkswagen");
			pst=con.prepareStatement("update accounts set balance=balance-? where accno=?;");
			pst.setDouble(1,amount);
			pst.setInt(2, sourceaccno);
			int cnt=pst.executeUpdate();
			if(cnt>0)
			{
				pst=con.prepareStatement("update accounts set balance=balance+? where accno=?;");
				pst.setDouble(1,amount);
				pst.setInt(2, destaccno);
				pst.executeUpdate();
				transferstatus="success";
			}
			con.close();
		}
		catch(Exception e)
		{
			transferstatus="error in transaction";
		}
		return(transferstatus);
	}
}
