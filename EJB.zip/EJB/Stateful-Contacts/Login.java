package com.soham.myservlets;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import javax.naming.InitialContext;
import com.soham.business.*;

/**
 * Servlet implementation class Login
 */
@WebServlet("/Login")
public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public Login() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		
		PrintWriter out=response.getWriter();
		response.setContentType("text/html");
		String ps;
		ps=request.getParameter("psw");
		
		if(ps.equals("oracle"))
		{
			
			try
			{
				InitialContext context=new InitialContext();
				ContactsEJBRemote obj=(ContactsEJBRemote) context.lookup("java:global/SessionTrackEnterprise/SessionTrackEJBProject/ContactsEJB!com.soham.business.ContactsEJBRemote");
				request.getSession().setAttribute("remote",obj);
				response.sendRedirect("User.jsp");
			}
			catch(Exception e)
			{
				out.println(e);
			}
			
		}
		else
		{
			out.println("<h3 style='color:red'>Incorrect Password</h3>");
			out.println("<a href='index.jsp'>Home</a>");
		}
		
	}

}
