package com.soham.business;

import java.util.ArrayList;

import javax.ejb.LocalBean;
import javax.ejb.Stateful;

/**
 * Session Bean implementation class ContactsEJB
 */
@Stateful(mappedName = "cont")
@LocalBean
public class ContactsEJB implements ContactsEJBRemote {

    /**
     * Default constructor. 
     */
	ArrayList<String> list;
    public ContactsEJB() {
    	list=new ArrayList<String>();
        // TODO Auto-generated constructor stub
    }
    
    public void addContact(String contactnm)
    {
    	list.add(contactnm);
    }
	
    public ArrayList<String> getContacts()
	{
		return(list);
	}

}
