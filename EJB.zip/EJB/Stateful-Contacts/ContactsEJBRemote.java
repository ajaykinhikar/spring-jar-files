package com.soham.business;

import java.util.ArrayList;

import javax.ejb.Remote;

@Remote
public interface ContactsEJBRemote {
	public void addContact(String contactnm);
	public ArrayList<String> getContacts();

}
