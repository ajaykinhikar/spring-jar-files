package com.boot.transactjpa;

import org.springframework.data.repository.CrudRepository;

public interface AccountsRepository extends CrudRepository<Accounts, Integer>{

	public Iterable<Accounts> findAccByType(String type);
}
