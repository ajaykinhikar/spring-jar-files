package com.boot.transactjpa;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

@Controller
public class TransactJPAController 
{
	@Autowired
	private AccountsRepository repo;
	
	@RequestMapping("transact")
	public String index()
	{	
		return "index.jsp";
	}
	
	@RequestMapping("newacc")
	public String newaccount()
	{	
		return "NewAccount.jsp";
	}
	
	@RequestMapping("createacc")
	public ModelAndView createAccount(Accounts acc)
	{
		ModelAndView mv=new ModelAndView();
		try
		{
			repo.save(acc);		
			mv.addObject("msg", "Account created successfully..");
		}
		catch(Exception ex) 
		{
			mv.addObject("msg", "Account creation failed : "+ex);
		}
		
		mv.setViewName("Result.jsp");
		return mv;
	}
	
	@RequestMapping("accreport")
	public ModelAndView showAccounts()
	{
		ModelAndView mv=new ModelAndView();
		
		Iterable<Accounts> alist=repo.findAll();
		mv.addObject("acclist",alist);
		mv.setViewName("AccountsReport.jsp");
		return mv;		
	}
	
//	@RequestMapping("deleteacc")
//	public ModelAndView deleteAccount(@RequestParam int accno)
//	{
//		ModelAndView mv=new ModelAndView();
//		try
//		{
//			repo.deleteById(accno);
//			mv.addObject("msg", "Account deleted successfully..");
//		}
//		catch(Exception ex) 
//		{
//			mv.addObject("msg", "Account deletion failed : "+ex);
//		}
//		
//		mv.setViewName("Result.jsp");
//		return mv;
//	}
	
	
	@RequestMapping("deleteacc")
	public String deleteAccount(@RequestParam int accno)
	{
		repo.deleteById(accno);
		return "accreport";
	}
	
}









