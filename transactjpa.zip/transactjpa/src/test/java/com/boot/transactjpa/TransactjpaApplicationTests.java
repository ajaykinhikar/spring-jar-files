package com.boot.transactjpa;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TransactjpaApplicationTests {

	@Test
	void contextLoads() {
	}

}
